<div class="container d-flex justify-content-center align-items-center vh-100">
<img src="{{ asset('tmp/src/assets/images/logos/pt9.png') }}" width="1000" alt="" />
    </div>