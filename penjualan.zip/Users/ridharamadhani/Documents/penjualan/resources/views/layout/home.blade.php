@include('layout.header')

@include('layout.menu')

@include('layout.navbar')

@include('layout.main')

@include('layout.footer')
