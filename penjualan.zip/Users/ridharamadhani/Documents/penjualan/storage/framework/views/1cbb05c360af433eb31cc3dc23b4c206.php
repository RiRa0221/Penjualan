
<div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4">Design and Developed by <a href="https://Ridha Ramadhani/" target="_blank"
            class="pe-1 text-primary text-decoration-underline">Ridha Ramadhani</a> Distributed by <a href="https://SMKN1">SMKN1 Bintim</a></p>
      </div>
    </div>
    <!-- End Body Wrapper -->
  </div>

  <script src="<?php echo e(asset('tmp/src/assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('tmp/src/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('tmp/src/assets/js/sidebarmenu.js')); ?>"></script>
  <script src="<?php echo e(asset('tmp/src/assets/js/app.min.js')); ?>"></script>
  <script src="<?php echo e(asset('tmp/src/assets/libs/apexcharts/dist/apexcharts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('tmp/src/assets/libs/simplebar/dist/simplebar.js')); ?>"></script>
  <script src="<?php echo e(asset('tmp/src/assets/js/dashboard.js')); ?>"></script>
</body>

</html>
<?php /**PATH /Users/ridharamadhani/Documents/penjualan/resources/views/layout/footer.blade.php ENDPATH**/ ?>