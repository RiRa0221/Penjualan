<div class="container d-flex justify-content-center align-items-center vh-100">
<img src="<?php echo e(asset('tmp/src/assets/images/logos/pt9.png')); ?>" width="1000" alt="" />
    </div><?php /**PATH /Users/ridharamadhani/Documents/penjualan/resources/views/layout/main.blade.php ENDPATH**/ ?>