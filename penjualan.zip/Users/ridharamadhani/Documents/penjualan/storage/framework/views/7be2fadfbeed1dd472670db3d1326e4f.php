<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<div class="container mt-5">
    <h2>Detail Penjualan</h2>

    <div class="card">
        <div class="card-body">
            <p><strong>Tanggal:</strong> <?php echo e($penjualan->tanggal_penjualan); ?></p>
            <p><strong>Total Harga:</strong> Rp <?php echo e(number_format($penjualan->total_harga, 2)); ?></p>
            <p><strong>Pelanggan:</strong> <?php echo e($penjualan->pelanggan->nama_pelanggan); ?></p>
        </div>
    </div>

    <a href="<?php echo e(route('penjualans.index')); ?>" class="btn btn-secondary mt-3">Kembali</a>
    <a href="<?php echo e(route('penjualans.edit', $penjualan)); ?>" class="btn btn-warning mt-3">Edit</a>
</div>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html><?php /**PATH /Users/ridharamadhani/Documents/penjualan/resources/views/penjualans/show.blade.php ENDPATH**/ ?>