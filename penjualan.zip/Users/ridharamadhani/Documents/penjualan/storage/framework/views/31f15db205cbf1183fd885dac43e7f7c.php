<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<div class="container mt-5">
    <h2>Detail Pelanggan</h2>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($pelanggan->nama_pelanggan); ?></h5>
            <p class="card-text"><strong>Alamat:</strong> <?php echo e($pelanggan->alamat); ?></p>
            <p class="card-text"><strong>Nomor Telepon:</strong> <?php echo e($pelanggan->nomor_telepon); ?></p>
        </div>
    </div>

    <a href="<?php echo e(route('pelanggans.index')); ?>" class="btn btn-secondary mt-3">Kembali</a>
    <a href="<?php echo e(route('pelanggans.edit', $pelanggan)); ?>" class="btn btn-warning mt-3">Edit</a>
</div>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php /**PATH /Users/ridharamadhani/Documents/penjualan/resources/views/pelanggans/show.blade.php ENDPATH**/ ?>